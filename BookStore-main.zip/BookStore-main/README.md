# BookStore

**Technology Stacks**

ExpressJS|MongoDB|EJS

**User Modules**

Registration|Login|Add Books|View Books|Cart and Checkout

**Admin Modules**

Login|View and Delete Users|View and Delete Books
