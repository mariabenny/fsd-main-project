const mongoose = require('mongoose')

const schema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    author: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: true
    },
    seller_id: {
        type: String,
        required: true
    },
    cover: {
        data: Buffer,
        contentType: String
    },
    price: {
        type: String,
        required: true
    }
}, {
    collection: "books"
})

module.exports = mongoose.model('books', schema)