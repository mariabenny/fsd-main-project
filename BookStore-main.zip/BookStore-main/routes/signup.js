const express = require('express')
const router = express.Router()
const user = require('../models/user')
const verify = require('../models/verify')
const mail = require('../services/mail.js')

router.get('/', async (req, res) => {
    try {
        res.render('signup')
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/', async (req, res) => {
    try {
        let uname = req.body.uname
        let em = req.body.email
        let pwd = req.body.pwd
        let repwd = req.body.repwd
        if (repwd != pwd) {
            res.render('signup', { msg: "Re-entered password mismatch. Please check" })
        }
        else if (await user.findOne({ username: uname })) {
            res.render('signup', { msg: "Name already used." })
        }
        else {
            let otp = await mail.send(em)
            await verify.deleteOne({ email: em })
            let v = new verify({
                username: uname,
                password: pwd,
                type: 'user',
                email: em,
                otp: otp
            })
            let t = await v.save()
            setTimeout(async () => {
                await verify.deleteOne({ email: em })
                console.log("Verification code expired.")
            }, 600000);
            req.session.vemail = em
            res.redirect('/verify')
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

module.exports = router