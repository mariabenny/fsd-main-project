const express = require('express')
const router = express.Router()
const book = require('../models/book')

router.get('/', async(req, res) => {
    try{
        if((req.session.isLoggedIn == 'true')&&(req.session.type == 'admin')){
            res.render('admindashboard')
        }
        else{
            res.redirect('/login')
        }
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router