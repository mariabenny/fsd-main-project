const express = require('express')
const router = express.Router()
const user = require('../models/user')

router.get('/', async(req, res) => {
    try{

        res.render('login', {msg: ""})
    }
    catch(e){
        res.send('Error:' + e)
    }
})

router.post('/', async(req, res) => {
    try{
        let uname = req.body.uname   
        let pwd = req.body.pwd
        let u = await user.findOne({ username: uname })
        if((u != null) && (u != "")){
            if(pwd == u.password){
                req.session.user = u._id
                req.session.type = u.type
                req.session.isLoggedIn = 'true'
                if(u.type == 'admin'){
                    res.redirect('/admin')    
                }
                else{
                    res.redirect('/dashboard')
                }
            }
        }
        else{
            res.render('login', {msg: "Provided username doesn't exist in our records!!"})
        }
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router