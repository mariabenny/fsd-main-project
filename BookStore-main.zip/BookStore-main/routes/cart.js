const express = require('express')
const router = express.Router()
const book = require('../models/book')
const cart = require('../models/cart')

router.get('/', async (req, res) => {
    try {
        if (req.session.isLoggedIn == 'true') {
            let c = await cart.findOne({ uid: req.session.user })
            let b = []
            for (let i in c.items) {
                let t = await book.findById(c.items[i].bid)
                t.n = c.items[i].n
                b.push(t)
            }
            res.render('cart', { books: b, credit: c.credit, cartId: c._id })
        }
        else {
            res.redirect('/login')
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/add', async (req, res) => {
    try {
        let flag = 0
        let c = await cart.findOne({ uid: req.session.user })
        let b = await book.findById(req.body.bookId)
        c.items.forEach(el => {
            if (el.bid.equals(b._id)) {
                el.n++
                flag = 1
            }
        })
        if (flag == 0) {
            c.items.push({
                bid: b._id,
                n: 1
            })
        }
        let t = await cart.updateOne({ uid: req.session.user }, { items: c.items })
        res.sendStatus(200)
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/remove', async (req, res) => {
    try {
        let c = await cart.findOne({ uid: req.session.user })
        for(let i in c.items){
            if (c.items[i].bid.equals(req.body.bookId)) {
                c.items.splice(i, 1)
            }
        }
        let t = await cart.updateOne({ uid: req.session.user }, { items: c.items })
        res.sendStatus(200)
    }
    catch (e) {
        res.send("Error: ", e)
    }
})
module.exports = router