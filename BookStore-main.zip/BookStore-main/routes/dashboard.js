const express = require('express')
const router = express.Router()
const book = require('../models/book')

router.get('/', async(req, res) => {
    try{
        if(req.session.isLoggedIn == 'true'){
            let b = await book.find({})
            res.render('dashboard', {books: b})
        }
        else{
            res.redirect('/login')
        }
    }
    catch(e){
        res.send('Error:' + e)
    }
})

module.exports = router