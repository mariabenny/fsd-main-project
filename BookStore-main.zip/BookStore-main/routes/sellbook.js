const express = require('express')
const router = express.Router()
const book = require('../models/book')
var multer = require('multer')
const fs = require('fs')
var path = require('path')

var upload = multer({ dest: '../uploads/' });

router.get('/', async (req, res) => {
    try {

        if (req.session.isLoggedIn == 'true') {
            res.render('sellbook')
        }
        else{
            res.redirect('/login')
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/', upload.single('cover'), async (req, res) => {
    try {

        let b = new book({
            name: req.body.bname,
            author: req.body.authname,
            description: req.body.desc,
            seller_id: req.session.user,
            cover: {
                data: fs.readFileSync('../uploads/' + req.file.filename),
                contentType: 'image/png'
            },
            price: req.body.price
        })
        const t = await b.save()
        res.redirect('/dashboard')
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

module.exports = router