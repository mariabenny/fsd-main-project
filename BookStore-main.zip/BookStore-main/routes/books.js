const express = require('express')
const router = express.Router()
const book = require('../models/book')
const user = require('../models/user')

router.get('/', async (req, res) => {
    try {
        if((req.session.isLoggedIn == 'true')&&(req.session.type == 'admin')){
            let b = await book.find({})
            for(let i in b){
                let u = await user.findById(b[i].seller_id)
                if(u == null){
                    b[i].seller = "Acount deleted"
                }
                else{
                    b[i].seller = u.username
                }
            }
            res.render('books', {books: b})
        }
        else {
            res.redirect('/login')
        }
    }
    catch (e) {
        res.send('Error:' + e)
    }
})

router.post('/remove', async (req, res) => {
    try {
        let t = await book.deleteOne({ _id: req.body.bookId })
        res.sendStatus(200)
    }
    catch (e) {
        res.send("Error: ", e)
    }
})

module.exports = router